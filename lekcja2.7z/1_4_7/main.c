#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n,m;
    do
    {
        scanf("%i",&n);
        scanf("%i",&m);
    }while (n>m);
    int wynik=n;
    for (int i=n+1; i<=m; i+=1)
    {
        wynik=wynik*i;
    }
    printf("%i",wynik);
}
