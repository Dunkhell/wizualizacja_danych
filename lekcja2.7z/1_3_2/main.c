#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;

    scanf("%i",&a);
    scanf("%i",&b);
    if (a > b)
    printf("wieksza liczba jest %i",a);
    if (b >a)
    printf("wieksza liczba jest %i",b);
    else
    printf("liczby sa rowne %i %i",a,b);
}
