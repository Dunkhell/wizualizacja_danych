#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,wynik=0;
    do
    {
        scanf("%i",&a);
    }while (a<0);
    for (int i=0;i <= a; i+=1)
    {
        wynik=wynik+pow(i,2);
    }
    printf("%i",wynik);
}
