#include <stdio.h>
#include <stdlib.h>

int main()
{
    int a,b;
    int i=1;
    int xb,xa;
   do
   {
       printf("Liczby musza byc dodatnie: \n");
       scanf("%i",&a);
       scanf("%i",&b);
   } while ( a<0 || b<0);
   if (a>b)
   {
       printf("Wielokrotnosciami %i sa: \n",b);

       do
       {
            xb=b*i;
            printf("%i\n",b*i);
            i=i+1;
       }while(a>xb);
   }
   if (a<b)
   {
       printf("Wielokrotnosciami %i sa: \n",a);

       do
       {
            xa=a*i;
            printf("%i\n",a*i);
            i=i+1;
       }while(xa<b);
   }
}
